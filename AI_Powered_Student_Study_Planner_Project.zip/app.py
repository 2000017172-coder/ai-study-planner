import streamlit as st
import pandas as pd
from datetime import date, timedelta
from pathlib import Path

st.set_page_config(page_title="AI Student Study Planner", page_icon="📚", layout="wide")

DATA_FILE = Path("study_tasks.csv")

def load_tasks():
    if DATA_FILE.exists():
        try:
            df = pd.read_csv(DATA_FILE)
            if "Done" not in df.columns:
                df["Done"] = False
            return df
        except Exception:
            pass
    return pd.DataFrame(columns=["Subject", "Task", "Due date", "Priority", "Done"])

def save_tasks(df):
    df.to_csv(DATA_FILE, index=False)

def make_study_plan(subjects, hours, exam_days):
    if not subjects:
        return ["Add at least one subject to create a plan."]
    hours = max(1, int(hours))
    weights = {"High": 3, "Medium": 2, "Low": 1}
    ranked = sorted(subjects, key=lambda s: weights.get(s["priority"], 1), reverse=True)
    slots = []
    for i in range(hours):
        s = ranked[i % len(ranked)]
        slots.append(f"{i+1}. {s['name']} — 1 hour ({s['priority']} priority)")
    return slots

def study_tips(subject, difficulty, available_time):
    tips = [
        f"Break {subject} into small topics and study one topic at a time.",
        "Use active recall: close your notes and explain the concept from memory.",
        "Solve a few practice questions, then review mistakes.",
        f"With {available_time} hour(s), use focused study blocks and short breaks."
    ]
    if difficulty == "Difficult":
        tips.insert(1, "Start with a worked example, then attempt a similar question independently.")
    elif difficulty == "Easy":
        tips.insert(1, "Spend less time rereading and more time testing what you remember.")
    return tips

st.title("📚 AI-Powered Student Study Planner")
st.caption("A beginner-friendly study planning assistant for organizing subjects, deadlines and study time.")
st.info("This prototype uses transparent, built-in planning logic. The recommendations are AI-inspired study support, not a substitute for your teacher's instructions.")

tasks = load_tasks()
subjects = st.session_state.get("subjects", [])

tab1, tab2, tab3, tab4 = st.tabs(["🏠 Dashboard", "📘 Subjects & Planner", "✅ Task Tracker", "💡 Study Assistant"])

with tab1:
    c1, c2, c3 = st.columns(3)
    c1.metric("Subjects added", len(subjects))
    c2.metric("Tasks", len(tasks))
    done_count = int(tasks["Done"].astype(str).str.lower().isin(["true", "1", "yes"]).sum()) if len(tasks) else 0
    c3.metric("Completed tasks", done_count)
    st.subheader("How to use the app")
    st.markdown("1. Add your subjects and set their priority.\n2. Generate a simple daily study plan.\n3. Add assignments or revision tasks with due dates.\n4. Mark tasks complete and export your tracker as CSV.")
    if len(tasks):
        st.subheader("Your task overview")
        st.dataframe(tasks, use_container_width=True, hide_index=True)
    else:
        st.write("No tasks yet. Open **Task Tracker** to add your first task.")

with tab2:
    st.subheader("Add your subjects")
    with st.form("subject_form"):
        name = st.text_input("Subject name", placeholder="e.g. Mathematics")
        priority = st.selectbox("Priority", ["High", "Medium", "Low"])
        difficulty = st.selectbox("Your difficulty level", ["Easy", "Moderate", "Difficult"])
        submitted = st.form_submit_button("Add subject")
        if submitted:
            if name.strip():
                subjects.append({"name": name.strip(), "priority": priority, "difficulty": difficulty})
                st.session_state["subjects"] = subjects
                st.success(f"{name.strip()} added.")
            else:
                st.warning("Please enter a subject name.")
    if subjects:
        st.subheader("Your subjects")
        st.dataframe(pd.DataFrame(subjects), use_container_width=True, hide_index=True)
        hours = st.slider("Study hours available today", 1, 12, 3)
        if st.button("Generate my study plan"):
            plan = make_study_plan(subjects, hours, 7)
            st.subheader("Suggested study plan")
            for item in plan:
                st.write("• " + item)
            st.caption("The plan rotates through your highest-priority subjects. Adjust it to match your timetable.")
    else:
        st.caption("Add at least one subject to generate a plan.")

with tab3:
    st.subheader("Assignment and revision tracker")
    with st.form("task_form"):
        task_subject = st.text_input("Subject")
        task_name = st.text_input("Task description", placeholder="e.g. Revise Unit 2")
        due = st.date_input("Due date", value=date.today() + timedelta(days=2))
        task_priority = st.selectbox("Task priority", ["High", "Medium", "Low"])
        add_task = st.form_submit_button("Add task")
        if add_task:
            if task_subject.strip() and task_name.strip():
                new_row = pd.DataFrame([{"Subject": task_subject.strip(), "Task": task_name.strip(),
                                         "Due date": str(due), "Priority": task_priority, "Done": False}])
                tasks = pd.concat([tasks, new_row], ignore_index=True)
                save_tasks(tasks)
                st.success("Task saved.")
                st.rerun()
            else:
                st.warning("Enter both a subject and task description.")
    if len(tasks):
        st.write("Update completion status below. Tick the box when a task is finished.")
        edited = st.data_editor(tasks, use_container_width=True, hide_index=True,
                                column_config={"Done": st.column_config.CheckboxColumn("Done")})
        if st.button("Save task updates"):
            save_tasks(edited)
            st.success("Updates saved.")
            st.rerun()
        st.download_button("Download task tracker (CSV)", tasks.to_csv(index=False).encode("utf-8"),
                           "study_tasks.csv", "text/csv")
    else:
        st.caption("Your tasks will appear here.")

with tab4:
    st.subheader("Personalized study suggestions")
    subject = st.text_input("Which subject do you want help with?", "Mathematics")
    difficulty = st.selectbox("How difficult does it feel?", ["Easy", "Moderate", "Difficult"], key="assistant_difficulty")
    available = st.slider("How many hours can you study?", 1, 8, 2, key="assistant_hours")
    if st.button("Get study suggestions"):
        for tip in study_tips(subject, difficulty, available):
            st.write("• " + tip)
        st.success("Suggestion generated. Review it and adapt it to your learning needs.")

st.divider()
st.caption("Mini Project 2 • AI Portfolio and Presentation | Prototype for educational use")
