# AI-Powered Student Study Planner

A beginner-friendly mini project that helps students organize subjects, study time, assignments and revision tasks.

## Features
- Dashboard with subject and task summary
- Subject list with High / Medium / Low priority
- Daily study-plan generator
- Assignment and revision tracker with due dates
- Completion tracking and CSV export
- Study assistant that provides context-based study suggestions

## Technology
- Python
- Streamlit
- Pandas

## Run on Windows
1. Install Python 3.10 or newer from https://www.python.org/downloads/.
2. Extract this ZIP folder.
3. Open the extracted folder in File Explorer.
4. Click the address bar, type `cmd`, and press Enter.
5. Run:
   ```bash
   py -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   streamlit run app.py
   ```
6. The app should open in your browser. If it does not, open the local URL shown in Command Prompt (usually http://localhost:8501).

## Publish on GitHub
1. Create a GitHub account and a new repository named `ai-student-study-planner`.
2. Upload `app.py`, `requirements.txt`, `README.md`, `Project_Report.docx`, and `Final_Presentation.pptx`.
3. Do not upload `.venv/` or private keys.
4. To deploy a public demo, use Streamlit Community Cloud and connect the GitHub repository. Choose `app.py` as the main file.

## Project note
This prototype uses transparent, rule-based study suggestions rather than a hosted generative-AI model, so it runs without an API key. In your presentation, describe it accurately as an AI-inspired planning assistant/prototype. A future version could connect to a generative AI API after adding secure key handling.

## Data
Tasks are saved locally in `study_tasks.csv` in the folder where the app is run. Keep a backup if the data matters.
